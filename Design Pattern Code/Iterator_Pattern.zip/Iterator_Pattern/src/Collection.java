public interface Collection {
	 public Iterator createIterator();
}
