public interface Iterator {//ITERATES THROUGH COLLECTION OF ITEMS IN WAREHOUSE
		 boolean hasNext();//NEXT ELEMENT IN ARRAY
		  Object next();
	}



