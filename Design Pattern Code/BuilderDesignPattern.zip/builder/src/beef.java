public class beef extends meats {

    @Override
    public float price() {
        return 20.0f;
    }

    @Override
    public String name() {
        return "beef";
    }
}
