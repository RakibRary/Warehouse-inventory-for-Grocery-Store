public interface Packaging {
    public String name();
    public Packing pack();
    public float price();
}



