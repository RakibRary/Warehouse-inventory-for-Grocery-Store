import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class orderTest {

    @Test
    void addItem() {
    }

    @Test
    void getCost() {
    }

    @Test
    void showItems() {
    }
}