public class Pork extends meats {

    @Override
    public float price() {
        return 15.0f;
    }

    @Override
    public String name() {
        return "Pork";
    }
}