public class referenceAdmin {
    public static void main(String[] args) {
        //reference single instance of admin
        admin object = admin.getInstance();

       //display message
       object.showMessage();
    }
}
