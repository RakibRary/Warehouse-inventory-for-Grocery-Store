public class bag implements Packing {
    @Override
    public String pack() {
        return "bag";
    }
}