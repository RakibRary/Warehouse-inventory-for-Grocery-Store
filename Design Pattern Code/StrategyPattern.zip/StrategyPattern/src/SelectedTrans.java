public interface SelectedTrans {
    public void trans(String transportationSelect, String storeID, String orderID);
}