public class greens extends veggies {

    @Override
    public float price() {
        return 3.0f;
    }

    @Override
    public String name() {
        return "greens";
    }
}
