// The orderObserver interface defines one method that allows you to send the alert
public interface orderObserver {
    void update(String status);
}
