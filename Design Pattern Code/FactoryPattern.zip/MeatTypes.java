public enum MeatTypes {
    BEEF,
    CHICKEN,
    PORK,
    TURKEY,
    BACON,
    HOTDOGS,
    SAUSAGE,
    ALTERNATIVE
}
