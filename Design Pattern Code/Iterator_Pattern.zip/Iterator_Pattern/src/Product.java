public class Product {//PRODUCT NAME
	 String product;
	 
	    public Product(String product){
	        this.product = product;
	    }
	    
	    public String getProduct(){
	        return product;
	    }
}
//LINKED LIST CAN BE IMPLEMENTS TO HOLD DIFFERENT ATTRIBUTES SUCH AS PRODUCT ID, COST, QAUNTITY