public class box implements Packing {
    @Override
    public String pack() {
        return "box";
    }
}
